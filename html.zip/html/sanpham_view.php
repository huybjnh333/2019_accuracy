<div class="imges_id_page" style="background-image:url(delete/load_page/2.jpg);"> </div>
<div class="link_page">
  <div class="pagewrap">
    <h3>Sản Phẩm Khuôn Mẫu</h3>
    <ul>
      <li><a href="#"><i class="fa fa-home"></i></a></li>
      <li><a href="#">trang chủ</a></li>
      <li><a href="#">Sản Phẩm</a></li>
      <li><a href="#">Sản Phẩm Khuôn Mẫu</a></li>
      <div class="clr"></div>
    </ul>
    <div class="clr"></div>
  </div>
</div>
<div class="pagewrap page_conten_page">
  <div class="padding_pagewrap">
    <div id="pro_img_main">
      <div id="bridal_images_list">
        <ul id="pro_img_slide">
          <li><a href='delete/sanpham/view/1.jpg' class='cloud-zoom-gallery' rel="useZoom: 'zoom1', smallImage: 'delete/sanpham/view/1.jpg'"><img src="delete/sanpham/view/1.jpg"></a></li>
          <li><a href='delete/sanpham/view/2.jpg' class='cloud-zoom-gallery' rel="useZoom: 'zoom1', smallImage: 'delete/sanpham/view/2.jpg'"><img src="delete/sanpham/view/2.jpg"></a></li>
          <li><a href='delete/sanpham/view/3.jpg' class='cloud-zoom-gallery' rel="useZoom: 'zoom1', smallImage: 'delete/sanpham/view/3.jpg'"><img src="delete/sanpham/view/3.jpg"></a></li>
          <li><a href='delete/sanpham/view/4.jpg' class='cloud-zoom-gallery' rel="useZoom: 'zoom1', smallImage: 'delete/sanpham/view/4.jpg'"><img src="delete/sanpham/view/4.jpg"></a></li>
        </ul>
        <script type="text/javascript" src="js/cloud-zoom.1.0.2.min.js"></script> 
      </div>
      <div id="bridal_images"> <a href='delete/sanpham/view/1.jpg' class='cloud-zoom' id='zoom1' rel="position: 'inside' , showTitle: false, adjustX:0, adjustY:0"><img src="delete/sanpham/view/1.jpg"></a> </div>
      
      <!--end viewLeft-->
      <div class="viewRight">
        <div class="titleView">KHUÔN DẬP LIÊN HOÀN</div>
        <h1>Giá: liên hệ</h1>
        <ul class="desc">
          <li>Mã sản phẩm: Magister C24</li>
          <li>Model: XPS-7</li>
          <li>Chất liệu: SWRM10Φ3.0.0</li>
          <li>Nhà cung cấp: ASMC</li>
          <li>Xuất xứ: Hà Lan</li>
          <li>Bảo hành:  12 tháng</li>
          <li>Lượt xem: 156</li>
          <li>Tình trạng: Còn hàng</li>
        </ul>
        <div class="clr"></div>
        <div class="clr"></div>
        <div id="sharelink"> 
          <!-- AddThis Button BEGIN -->
          <div class="addthis_toolbox addthis_default_style "> <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_google_plusone" g:plusone:size="medium"></a> <a class="addthis_counter addthis_pill_style"></a> </div>
          <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-502225fb496239a5"></script> 
          <!-- AddThis Button END --> 
        </div>
        <div class="chitiet_sp">
          <h4><a href="index.php?page=lienhe">đặt hàng ngay</a></h4>
        </div>
      </div>
      <!--end viewRight-->
      <div class="clr"></div>
    </div>
  </div>
</div>
<div class="tintuc_home_box">
  <div class="pagewrap">
    <div class="titBox left">
      <div class="tit_2">sản phẩm liên quan</div>
    </div>
    <div class="pro_home pro_home_2">
      <div class="placeSlide_main">
        <div class="placeSlide">
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/6.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/7.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/8.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/9.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/10.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/11.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=sanpham_view">
            <li><img src="delete/sanpham/12.jpg" width="600" height="400" /></li>
            <h4>KHUÔN DẬP LIÊN HOÀN</h4>
            <p>Mã sản phẩm: AA0021</p>
            <p>Chất liệu: SWRM10Φ3.0.0</p>
            <p>Nhà cung cấp: ASMC</p>
            </a>
          </ul>
        </div>
        <a href="#" class="placeNav_2 prev">&lsaquo;</a><a href="#" class="placeNav_2 next">&rsaquo;</a> 
        <script type="text/javascript">

				jQuery(document).ready(function(){

					var $placeSlide = $('.placeSlide');

					$placeSlide.imagesLoaded( function(){

				    	$(".placeSlide").carouFredSel({

							circular: false,

							infinite: true,

							auto 	: {

								pauseDuration : 5000,

							},

							scroll	: {

								items	: 1,

								fx		: 'linear'

							},

							prev	: ".placeNav_2.prev",

							next	: ".placeNav_2.next",

							swipe: {

								onMouse: true,

								onTouch: true

							},



							items : {

								height: "variable"

							}

						});

					});

		    	});

		    </script> 
      </div>
    </div>
  </div>
</div>
