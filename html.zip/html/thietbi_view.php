<div class="imges_id_page" style="background-image:url(delete/load_page/7.jpg);"> </div>
<div class="link_page">
  <div class="pagewrap">
    <h3>Thiết Bị Chế Tạo Khuôn/Gá</h3>
    <ul>
      <li><a href="#"><i class="fa fa-home"></i></a></li>
      <li><a href="#">trang chủ</a></li>
      <li><a href="#">Thiết Bị</a></li>
      <li><a href="#">Thiết Bị Chế Tạo Khuôn/Gá</a></li>
      <div class="clr"></div>
    </ul>
    <div class="clr"></div>
  </div>
</div>
<div class="pagewrap page_conten_page">
  <div class="padding_pagewrap">
    <div class="noidung_ct_left">
      <div class="tt_duan_id">
        <ul>
          <h3>MÁY CẮT LASER</h3>
          <p>Hãng sản xuất:AMADA</p>
          <p>Model: AMADA FO123</p>
          <p>Hành trình cắt: 1500 x 3070 x 2520</p>
          <p>Điều khiển: CNC FANUC 160I L</p>
          <p>Xuất xứ:JAPAN</p>
          <p>Tại ACCURACY  chúng tôi luôn tâm niệm rằng tạo dựng những giá trị vững chắc chính là chìa khóa cho kinh doanh thành công, thực hiện triết lý kinh doanh là làm hài hòa lợi ích của xã hội, lợi ích của đối tác và lợi ích của công ty. Mọi nỗ lực của chúng tôi đều vì một mục tiêu chung của công ty. </p>
        </ul>
      </div>
      <div id="sharelink"> 
        <!-- AddThis Button BEGIN -->
        <div class="addthis_toolbox addthis_default_style "> <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a> <a class="addthis_button_tweet"></a> <a class="addthis_button_google_plusone" g:plusone:size="medium"></a> <a class="addthis_counter addthis_pill_style"></a> </div>
        <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-502225fb496239a5"></script> 
        <!-- AddThis Button END --> 
      </div>
    </div>
    <div class="hinhanh_ct_right">
<div class="container"> 
          <!-- Full-width images with number text -->
          <div class="mySlides"> <img src="delete/tintuc/view/1.jpg" style="width:100%"> </div>
          <div class="mySlides"> <img src="delete/tintuc/view/2.jpg" style="width:100%"> </div>
          <div class="mySlides"> <img src="delete/tintuc/view/3.jpg" style="width:100%"> </div>
          <div class="mySlides"> <img src="delete/tintuc/view/4.jpg" style="width:100%"> </div>
          <div class="mySlides"> <img src="delete/tintuc/view/5.jpg" style="width:100%"> </div>
          <!-- Next and previous buttons --> 
          <a class="prev" onclick="plusSlides(-1)">&#10094;</a> <a class="next" onclick="plusSlides(1)">&#10095;</a> 
          <!-- Image text -->
          <div class="caption-container">
            <p id="caption"></p>
          </div>
          <!-- Thumbnail images -->
          <div class="row">
            <div class="column"> <img class="demo cursor" src="delete/tintuc/view/1.jpg" style="width:100%" onclick="currentSlide(1)"> </div>
            <div class="column"> <img class="demo cursor" src="delete/tintuc/view/2.jpg" style="width:100%" onclick="currentSlide(2)"> </div>
            <div class="column"> <img class="demo cursor" src="delete/tintuc/view/3.jpg" style="width:100%" onclick="currentSlide(3)"> </div>
            <div class="column"> <img class="demo cursor" src="delete/tintuc/view/4.jpg" style="width:100%" onclick="currentSlide(4)"> </div>
            <div class="column"> <img class="demo cursor" src="delete/tintuc/view/5.jpg" style="width:100%" onclick="currentSlide(5)"> </div>
          </div>
        </div>
        <script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script> 
    </div>
    <div class="clr"></div>
  </div>
</div>
<div class="tintuc_home_box">
  <div class="pagewrap">
    <div class="titBox left">
      <div class="tit_2">bài viết liên quan</div>
    </div>
    <div class="pro_home">
      <div class="placeSlide_main">
        <div class="placeSlide">
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/6.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/7.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/8.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/9.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/10.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/11.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
          <ul>
            <a href="index.php?page=thietbi_view">
            <li><img src="delete/tintuc/12.jpg" width="380" height="250" /></li>
            <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
            <p></p>
            </a>
          </ul>
        </div>
        <a href="#" class="placeNav_2 prev">&lsaquo;</a><a href="#" class="placeNav_2 next">&rsaquo;</a> 
        <script type="text/javascript">

				jQuery(document).ready(function(){

					var $placeSlide = $('.placeSlide');

					$placeSlide.imagesLoaded( function(){

				    	$(".placeSlide").carouFredSel({

							circular: false,

							infinite: true,

							auto 	: {

								pauseDuration : 5000,

							},

							scroll	: {

								items	: 1,

								fx		: 'linear'

							},

							prev	: ".placeNav_2.prev",

							next	: ".placeNav_2.next",

							swipe: {

								onMouse: true,

								onTouch: true

							},



							items : {

								height: "variable"

							}

						});

					});

		    	});

		    </script> 
      </div>
    </div>
  </div>
</div>
