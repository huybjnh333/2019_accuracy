<div class="imges_id_page" style="background-image:url(delete/load_page/7.jpg);"> </div>
<div class="link_page">
  <div class="pagewrap">
    <h3>Thiết Bị Chế Tạo Khuôn/Gá</h3>
    <ul>
      <li><a href="#"><i class="fa fa-home"></i></a></li>
      <li><a href="#">trang chủ</a></li>
      <li><a href="#">Thiết Bị</a></li>
      <li><a href="#">Thiết Bị Chế Tạo Khuôn/Gá</a></li>
      <div class="clr"></div>
    </ul>
    <div class="clr"></div>
  </div>
</div>
<div class="pagewrap page_conten_page">
  <div class="pro_home">
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/1.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/2.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/3.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/4.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/5.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/6.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/7.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/8.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/9.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/10.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/11.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=thietbi_view">
      <li><img src="delete/tintuc/12.jpg" width="380" height="250" /></li>
      <h4>tên Thiết Bị Chế Tạo Khuôn/Gá</h4>
      <p></p>
      </a>
    </ul>
    <div class="clr"></div>
  </div>
  <div class="nums">
    <ul>
      <li><a href="#" class="stay"><</a></li>
      <li><a href="#" class="active">1</a></li>
      <li><a href="#">2</a></li>
      <li><a href="#">3</a></li>
      <li><a href="#">4</a></li>
      <li><a href="#">5</a></li>
      <li><a href="#" class="stay">></a></li>
    </ul>
    <div class="clr"></div>
  </div>
</div>
