<div class="imges_id_page" style="background-image:url(delete/load_page/4.jpg);"> </div>
<div class="link_page">
  <div class="pagewrap">
    <h3>Tin Tức Nội Bộ</h3>
    <ul>
      <li><a href="#"><i class="fa fa-home"></i></a></li>
      <li><a href="#">trang chủ</a></li>
      <li><a href="#">hoạt động công ty</a></li>
      <li><a href="#">Tin Tức Nội Bộ</a></li>
      <div class="clr"></div>
    </ul>
    <div class="clr"></div>
  </div>
</div>
<div class="pagewrap page_conten_page">
  <div class="tintuc_home_id">
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/18.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/17.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/16.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/14.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/15.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/6.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/13.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/12.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/11.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/10.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/9.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <ul>
      <li><a href="index.php?page=hoatdong_view"><img src="delete/tintuc/8.jpg" width="400" height="245" /></a></li>
      <h4><i class="fa fa-calendar"></i>Thứ ba, 11:30 Ngày 05/06/2018.</h4>
      <h3><a href="index.php?page=hoatdong_view">Mở rộng cơ sở sản xuất kinh doanh, nên bắt đầu từ đâu?</a></h3>
      <p>We work with the companies that have established a stainless reputation in what they do. They are leaders in various spheres of business, and we appreciate cooperating with them... </p>
    </ul>
    <div class="clr"></div>
  </div>
  <div class="nums">
    <ul>
      <li><a href="#" class="stay"><</a></li>
      <li><a href="#" class="active">1</a></li>
      <li><a href="#">2</a></li>
      <li><a href="#">3</a></li>
      <li><a href="#">4</a></li>
      <li><a href="#">5</a></li>
      <li><a href="#" class="stay">></a></li>
    </ul>
    <div class="clr"></div>
  </div>
</div>