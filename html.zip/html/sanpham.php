<div class="imges_id_page" style="background-image:url(delete/load_page/2.jpg);"> </div>
<div class="link_page">
  <div class="pagewrap">
    <h3>Sản Phẩm Khuôn Mẫu</h3>
    <ul>
      <li><a href="#"><i class="fa fa-home"></i></a></li>
      <li><a href="#">trang chủ</a></li>
      <li><a href="#">Sản Phẩm</a></li>
      <li><a href="#">Sản Phẩm Khuôn Mẫu</a></li>
      <div class="clr"></div>
    </ul>
    <div class="clr"></div>
  </div>
</div>
<div class="pagewrap page_conten_page">
  <div class="pro_home pro_home_2">
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/1.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/2.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/3.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/4.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/5.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/6.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/7.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/8.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/9.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/10.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/11.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <ul>
      <a href="index.php?page=sanpham_view">
      <li><img src="delete/sanpham/12.jpg" width="600" height="400" /></li>
      <h4>KHUÔN DẬP LIÊN HOÀN</h4>
      <p>Mã sản phẩm: AA0021</p>
      <p>Chất liệu: SWRM10Φ3.0.0</p>
      <p>Nhà cung cấp: ASMC</p>
      </a>
    </ul>
    <div class="clr"></div>
  </div>
  <div class="nums">
    <ul>
      <li><a href="#" class="stay"><</a></li>
      <li><a href="#" class="active">1</a></li>
      <li><a href="#">2</a></li>
      <li><a href="#">3</a></li>
      <li><a href="#">4</a></li>
      <li><a href="#">5</a></li>
      <li><a href="#" class="stay">></a></li>
    </ul>
    <div class="clr"></div>
  </div>
</div>
