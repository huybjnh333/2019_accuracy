<div class="imges_id_page" style="background-image:url(delete/load_page/6.jpg);"> </div>
<div class="link_page">
  <div class="pagewrap">
    <h3>liên hệ</h3>
    <ul>
      <li><a href="#"><i class="fa fa-home"></i></a></li>
      <li><a href="#">trang chủ</a></li>
      <li><a href="#">liên hệ</a></li>
      <div class="clr"></div>
    </ul>
    <div class="clr"></div>
  </div>
</div>
<div class="pagewrap page_conten_page">
  <div class="company_contact">
    <ul>
      <h3><i class="fa fa-home"></i>trụ sở chính</h3>
      <p><i class="fa fa-map-marker"></i>Phố An Định, Khu hành chính số 8, phường Đống Đa, TP. Vĩnh Yên, tỉnh Vĩnh Phúc.</p>
    </ul>
    <ul>
      <h3><i class="fa fa-globe"></i>điện thoại</h3>
      <p><i class="fa fa-phone"></i>Điện thoại: (+84) 211 3722105 </p>
      <p><i class="fa fa-volume-control-phone"></i>Hotline: 0814.26.88.99</p>
    </ul>
    <ul>
      <h3><i class="fa fa-envelope"></i>email - website</h3>
      <p><i class="fa fa-envelope"></i>Email: sales@accuracy.vn</p>
      <p><i class="fa fa-globe"></i>Website: www.accuracy.vn</p>
    </ul>
    <div class="clr"></div>
  </div>
  <div class="padding_pagewrap">
    <div class="contact">
      <form action="#" class="formBox" method="post" name="FormNameContact" id="FormNameContact">
        <div class="left">
          <li class="name">
            <input name="s_fullname" type="text" placeholder="Họ và tên" value="Họ và tên" onFocus="if (this.value == 'Họ và tên'){this.value='';}" onBlur="if (this.value == '') {this.value='Họ và tên';}"/>
          </li>
          <li class="phone">
            <input name="s_dienthoai" type="text" placeholder="Số điện thoại" value="Số điện thoại" onFocus="if (this.value == 'Số điện thoại'){this.value='';}" onBlur="if (this.value == '') {this.value='Số điện thoại';}"/>
          </li>
          <li class="mail">
            <input name="s_email" type="text" placeholder="Email" value="Email" onFocus="if (this.value == 'Email'){this.value='';}" onBlur="if (this.value == '') {this.value='Email';}"/>
          </li>
          <li class="local">
            <input name="s_address" type="text" placeholder="Địa chỉ" value="Địa chỉ" onFocus="if (this.value == 'Địa chỉ'){this.value='';}" onBlur="if (this.value == '') {this.value='Địa chỉ';}"/>
          </li>
          <li class="subject">
            <input name="s_title" type="text" placeholder="Tiêu đề" value="Tiêu đề" onFocus="if (this.value == 'Tiêu đề'){this.value='';}" onBlur="if (this.value == '') {this.value='Tiêu đề';}"/>
          </li>
        </div>
        <div class="right">
          <li class="mess">
            <textarea name="s_message" cols="" rows="" placeholder="Nội dung" value="Nội dung" onFocus="if (this.value == 'Nội dung'){this.value='';}" onBlur="if (this.value == '') {this.value='Nội dung';}"></textarea>
          </li>
          <li class="code"><span>489540</span>
            <input name="mabaove" type="text" placeholder="Mã bảo vệ" value="Mã bảo vệ" onFocus="if (this.value == 'Mã bảo vệ'){this.value='';}" onBlur="if (this.value == '') {this.value='Mã bảo vệ';}"/>
          </li>
          <a onclick="RefreshFormMailContact()" style="cursor:pointer" class="button">Làm lại</a><a onclick="CheckFormMailContact()" style="cursor:pointer" class="button">Gửi</a> </div>
        <div class="clr"></div>
        <input name="mabaovehidden" type="hidden" id="mabaovehidden" value="489540">
      </form>
    </div>
  </div>
</div>
<div class="map_contact">
  <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14868.494794674154!2d105.6000586!3d21.306128!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb24bb34f0f1ef03e!2zQ8O0bmcgdHkgY-G7lSBwaOG6p24gQWNjdXJhY3k!5e0!3m2!1sen!2s!4v1575021961540!5m2!1sen!2s" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</div>
